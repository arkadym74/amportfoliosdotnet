﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace grade_calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            //Program's welcoming informative message
            Console.WriteLine("\nWelcome to grade calculator, \nit calculates student's grade based on student's score");

            //Declaring variables
            double studentScore = 0, studentPercent = 0;
            string letterGrade = "A", fullName = "";

            //Teacher inputs student's name and score
            Console.Write("\nPlease enter student's Full Name ex. John Smith:");
            fullName = Console.ReadLine();
            Console.Write("\nPlease enter student's score:");
            studentScore = Convert.ToDouble(Console.ReadLine());
            studentPercent = studentScore / 1000;
            // Based on conditions below student will get good or bad grade
            if (studentScore < 0 || studentScore > 1000)
            {
                Console.Write("\nThis is an error, Please press enter to exit application. Thank you.");
                Console.ReadLine();
                Environment.Exit(0);
            }

            else

            if (studentPercent >= 0.90)
                letterGrade = "A";
            else
                if (studentPercent >= 0.80)
                letterGrade = "B";
            else
                    if (studentPercent >= 0.70)
                letterGrade = "C";
            else
                    if (studentPercent >= 0.60)
                letterGrade = "D";
            else
                if (studentPercent >= 0)
                letterGrade = "F";
            //else
                //if (studentScore < 0 || studentScore > 1000)
                //Console.Write("\nThis is an error, Exiting application");
                //System.Environment.Exit(-1);

            Console.Write("\nHere is the student's Full Name: " + fullName);
            Console.Write("\nStudent has " + studentScore + " points score");
            Console.Write("\nHere is how much percent student has " + studentPercent.ToString("P1"));
            Console.Write("\nHere is student's letter grade:\t " + letterGrade);
            Console.ReadLine();
        }
    }
}




